PMS full database export
Generated: 20260723-142315
Apps: accounts, equipment, borrowing, maintenance, reports, core, auth

Restore via Admin:
  /admin/download-database/  →  Import section

Or via CLI (migrations applied):
  python manage.py loaddata pms-database-YYYYMMDD.json

Admin import merges data (adds/updates) and does not wipe rows.
Note: Uploaded media files (logos, avatars, QR images) are NOT included.
User password hashes ARE included — treat this file as confidential.
